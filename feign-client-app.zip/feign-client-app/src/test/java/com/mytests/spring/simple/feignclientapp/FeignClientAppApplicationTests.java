package com.mytests.spring.simple.feignclientapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignClientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
